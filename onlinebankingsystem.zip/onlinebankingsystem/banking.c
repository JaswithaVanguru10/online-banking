// banking.c
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "banking.h"

void createAccount() {
    FILE *fp = fopen("accounts.dat", "ab");
    struct Account acc;

    printf("\nEnter Name: ");
    scanf(" %[^\n]", acc.name);
    printf("Enter Account Number: ");
    scanf("%d", &acc.acc_number);
    printf("Enter Initial Balance: ");
    scanf("%f", &acc.balance);

    fwrite(&acc, sizeof(acc), 1, fp);
    fclose(fp);

    printf("✅ Account created successfully!\n");
}

void displayAccount() {
    FILE *fp = fopen("accounts.dat", "rb");
    struct Account acc;
    int acc_no, found = 0;

    printf("Enter Account Number: ");
    scanf("%d", &acc_no);

    while (fread(&acc, sizeof(acc), 1, fp)) {
        if (acc.acc_number == acc_no) {
            printf("\nName: %s\nAccount Number: %d\nBalance: %.2f\n", acc.name, acc.acc_number, acc.balance);
            found = 1;
            break;
        }
    }
    if (!found) printf("❌ Account not found.\n");
    fclose(fp);
}

void deposit() {
    FILE *fp = fopen("accounts.dat", "rb+");
    struct Account acc;
    int acc_no;
    float amount;

    printf("Enter Account Number: ");
    scanf("%d", &acc_no);

    while (fread(&acc, sizeof(acc), 1, fp)) {
        if (acc.acc_number == acc_no) {
            printf("Enter amount to deposit: ");
            scanf("%f", &amount);
            acc.balance += amount;

            fseek(fp, -sizeof(acc), SEEK_CUR);
            fwrite(&acc, sizeof(acc), 1, fp);
            printf("✅ Deposit successful!\n");
            fclose(fp);
            return;
        }
    }
    printf("❌ Account not found.\n");
    fclose(fp);
}

void withdraw() {
    FILE *fp = fopen("accounts.dat", "rb+");
    struct Account acc;
    int acc_no;
    float amount;

    printf("Enter Account Number: ");
    scanf("%d", &acc_no);

    while (fread(&acc, sizeof(acc), 1, fp)) {
        if (acc.acc_number == acc_no) {
            printf("Enter amount to withdraw: ");
            scanf("%f", &amount);
            if (amount > acc.balance) {
                printf("❌ Insufficient balance.\n");
            } else {
                acc.balance -= amount;
                fseek(fp, -sizeof(acc), SEEK_CUR);
                fwrite(&acc, sizeof(acc), 1, fp);
                printf("✅ Withdrawal successful!\n");
            }
            fclose(fp);
            return;
        }
    }
    printf("❌ Account not found.\n");
    fclose(fp);
}

void checkBalance() {
    displayAccount(); // Reuses display function
}

void deleteAccount() {
    FILE *fp = fopen("accounts.dat", "rb");
    FILE *temp = fopen("temp.dat", "wb");
    struct Account acc;
    int acc_no, found = 0;

    printf("Enter Account Number to delete: ");
    scanf("%d", &acc_no);

    while (fread(&acc, sizeof(acc), 1, fp)) {
        if (acc.acc_number != acc_no) {
            fwrite(&acc, sizeof(acc), 1, temp);
        } else {
            found = 1;
        }
    }

    fclose(fp);
    fclose(temp);
    remove("accounts.dat");
    rename("temp.dat", "accounts.dat");

    if (found)
        printf("✅ Account deleted successfully.\n");
    else
        printf("❌ Account not found.\n");
}
