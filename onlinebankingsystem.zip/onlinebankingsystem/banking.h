// banking.h
#ifndef BANKING_H
#define BANKING_H

struct Account {
    char name[50];
    int acc_number;
    float balance;
};

// Function declarations
void createAccount();
void displayAccount();
void deposit();
void withdraw();
void checkBalance();
void deleteAccount();

#endif
