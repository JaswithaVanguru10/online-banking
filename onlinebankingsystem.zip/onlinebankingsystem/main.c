#include <stdio.h>
#include "banking.h"  // ✅ Fixed: Properly closed the include

int main() {
    int choice;

    while (1) {
        printf("\n====== Online Banking System ======\n");
        printf("1. Create Account\n");
        printf("2. View Account\n");
        printf("3. Deposit\n");
        printf("4. Withdraw\n");
        printf("5. Check Balance\n");
        printf("6. Delete Account\n");
        printf("7. Exit\n");
        printf("Choose an option: ");
        scanf("%d", &choice);

        switch (choice) {
            case 1: createAccount(); break;
            case 2: displayAccount(); break;
            case 3: deposit(); break;
            case 4: withdraw(); break;
            case 5: checkBalance(); break;
            case 6: deleteAccount(); break;
            case 7:
                printf("👋 Thank you for using the Banking System.\n");
                return 0;
            default:
                printf("❌ Invalid choice. Please try again.\n");
        }
    }
}
